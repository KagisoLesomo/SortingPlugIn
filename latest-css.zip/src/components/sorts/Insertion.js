import React from "react";

const InsertionSort = () => {
return (
	<div>
	<h1>INSERTION SORT</h1>
	<h2>Stuff about insertion sort:</h2>
	</div>
);
};

export default InsertionSort;

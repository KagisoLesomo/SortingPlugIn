import React from "react";

const SelectionSort = () => {
return (
	<div>
	<h1>SELECTION SORT</h1>
	<h2>Stuff about selection sort:</h2>
	</div>
);
};

export default SelectionSort;

import React from "react";

const BubbleSort = () => {
return (
	<div>
	<h1>BUBBLE SORT</h1>
	<h2>Stuff about bubble sort:</h2>
	</div>
);
};

export default BubbleSort;

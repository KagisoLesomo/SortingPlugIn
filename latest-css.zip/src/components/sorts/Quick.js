import React from "react";

const QuickSort = () => {
	return (
		<div>
		<h1>QUICK SORT</h1>
		<h2>Stuff about quick sort:</h2>
		</div>
	);
};

export default QuickSort;

import React from "react";

export const OtherSort = () => {
return (
	<div>
	<h1>OTHER SORT</h1>
	<h2>Stuff about other sort: As default for putting another sort into the site</h2>

	</div>
);
};

//export default OtherSort;

//FIX:
//these are the sub pages for sort (supposed to be), but they are not working/showing on the sidebar for some reason :(
export const Overview = () => {
	return (
		<div>
		<h1>Brief overview about this sort</h1>
		<h2>Stuff about this sort and visualiser</h2>
		</div>
	);
};
		
export const Practice = () => {
	return (
		<div>
		<h1>Practicing this sort: Quizzes and stuff</h1>
		</div>
	);
};
	

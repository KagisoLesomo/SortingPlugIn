// src/components/testPage.js
import React from 'react';

const testPage = () => {
  return (
    <div>
      <h2>Test Mode</h2>
      {/* Add test content here */}
    </div>
  );
};

export default testPage;
